
<!--session_start() ?>-->
<!--<!DOCTYPE html>-->
<!--<html class="no-js" lang="en-US">-->

<!--<head>-->
<!--    <meta charset="utf-8">-->
<!--    <meta name="google-site-verification" content="IERPw5o4Pq7Qqfg40O-XWhvOBuRhEXggKD5QIwJSuxc" />-->
<!--    <link rel="preload"-->
<!--        href="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/cache/fvm/min/1687458765-cssf896c874918969d9d20a777bf47d8a5b01d174508c20d246abd8b88559021.css"-->
<!--        as="style" media="all">-->
<!--    <link rel="preload"-->
<!--        href="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/themes/JointsWP-CSS-master/assets/scripts/jquery.min.js"-->
<!--        as="script">-->



<!--    <meta name="twitter:image"-->
<!--        content="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/08/home-hero-social-sharing.png">-->
<!--    <meta name="twitter:site" content="@Bitly">-->

<!--    <link rel="canonical" href="https://bitly.com/">-->
<!--    <meta name="updated-canonical" value="true">-->
<!--    <meta name="google-site-verification" content="VxdtAjqaA6XhwRJO86fcIZtRDqJAzUqlgS8AwZHmd3o">-->
<!--    <meta name="google-site-verification" content="v0y6aY7uUXw-qQm9w0YTh4VBwOMfELJ-YKG7pCd5RoQ">-->
<!--    <link rel="preload" fetchpriority="low" id="fvmfonts-css"-->
<!--        href="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/cache/fvm/min/1687458765-css7ec7df5f16631b30de39c3ed0a4afc5dee09846929d22c1bf8cd1a835ca6b.css"-->
<!--        as="style" media="all" onload="this.rel='stylesheet';this.onload=null">-->
<!--    <link rel="stylesheet"-->
<!--        href="asset/static/1687458771/pages/wp-content/cache/fvm/min/1687458765-cssf896c874918969d9d20a777bf47d8a5b01d174508c20d246abd8b88559021.css"-->
<!--        media="all">-->
<!--    <script data-cfasync="false"-->
<!--        src="asset/static/1687458771/pages/wp-content/themes/JointsWP-CSS-master/assets/scripts/jquery.min.js"></script>-->
<!--    <script defer-->
<!--        src="asset/static/1687458771/pages/wp-content/cache/fvm/min/1687458765-js33dea76949edd6f99c859959b54125ec8fae8fa3bb05f2ae6d42121e07ad1e.js"></script>-->

<!--    <script id="optimizelyscript">-->
<!--        var a = 1;-->
<!--    </script>-->
<!--    <style id="safe-svg-svg-icon-style-inline-css" type="text/css" media="all">-->
<!--        .safe-svg-cover .safe-svg-inside {-->
<!--            display: inline-block;-->
<!--            max-width: 100%-->
<!--        }-->

<!--        .safe-svg-cover svg {-->
<!--            height: 100%;-->
<!--            max-height: 100%;-->
<!--            max-width: 100%;-->
<!--            width: 100%-->
<!--        }-->
<!--    </style>-->
<!--    <style id="global-styles-inline-css" type="text/css" media="all">-->
<!--        body {-->
<!--            --wp--preset--color--black: #000000;-->
<!--            --wp--preset--color--cyan-bluish-gray: #abb8c3;-->
<!--            --wp--preset--color--white: #ffffff;-->
<!--            --wp--preset--color--pale-pink: #f78da7;-->
<!--            --wp--preset--color--vivid-red: #cf2e2e;-->
<!--            --wp--preset--color--luminous-vivid-orange: #ff6900;-->
<!--            --wp--preset--color--luminous-vivid-amber: #fcb900;-->
<!--            --wp--preset--color--light-green-cyan: #7bdcb5;-->
<!--            --wp--preset--color--vivid-green-cyan: #00d084;-->
<!--            --wp--preset--color--pale-cyan-blue: #8ed1fc;-->
<!--            --wp--preset--color--vivid-cyan-blue: #0693e3;-->
<!--            --wp--preset--color--vivid-purple: #9b51e0;-->
<!--            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);-->
<!--            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);-->
<!--            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);-->
<!--            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);-->
<!--            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);-->
<!--            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);-->
<!--            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);-->
<!--            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);-->
<!--            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);-->
<!--            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);-->
<!--            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);-->
<!--            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);-->
<!--            --wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');-->
<!--            --wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');-->
<!--            --wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');-->
<!--            --wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');-->
<!--            --wp--preset--duotone--midnight: url('#wp-duotone-midnight');-->
<!--            --wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');-->
<!--            --wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');-->
<!--            --wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');-->
<!--            --wp--preset--font-size--small: 13px;-->
<!--            --wp--preset--font-size--medium: 20px;-->
<!--            --wp--preset--font-size--large: 36px;-->
<!--            --wp--preset--font-size--x-large: 42px;-->
<!--            --wp--preset--spacing--20: 0.44rem;-->
<!--            --wp--preset--spacing--30: 0.67rem;-->
<!--            --wp--preset--spacing--40: 1rem;-->
<!--            --wp--preset--spacing--50: 1.5rem;-->
<!--            --wp--preset--spacing--60: 2.25rem;-->
<!--            --wp--preset--spacing--70: 3.38rem;-->
<!--            --wp--preset--spacing--80: 5.06rem-->
<!--        }-->

<!--        :where(.is-layout-flex) {-->
<!--            gap: .5em-->
<!--        }-->

<!--        body .is-layout-flow>.alignleft {-->
<!--            float: left;-->
<!--            margin-inline-start: 0;-->
<!--            margin-inline-end: 2em-->
<!--        }-->

<!--        body .is-layout-flow>.alignright {-->
<!--            float: right;-->
<!--            margin-inline-start: 2em;-->
<!--            margin-inline-end: 0-->
<!--        }-->

<!--        body .is-layout-flow>.aligncenter {-->
<!--            margin-left: auto !important;-->
<!--            margin-right: auto !important-->
<!--        }-->

<!--        body .is-layout-constrained>.alignleft {-->
<!--            float: left;-->
<!--            margin-inline-start: 0;-->
<!--            margin-inline-end: 2em-->
<!--        }-->

<!--        body .is-layout-constrained>.alignright {-->
<!--            float: right;-->
<!--            margin-inline-start: 2em;-->
<!--            margin-inline-end: 0-->
<!--        }-->

<!--        body .is-layout-constrained>.aligncenter {-->
<!--            margin-left: auto !important;-->
<!--            margin-right: auto !important-->
<!--        }-->

<!--        body .is-layout-constrained>:where(:not(.alignleft):not(.alignright):not(.alignfull)) {-->
<!--            max-width: var(--wp--style--global--content-size);-->
<!--            margin-left: auto !important;-->
<!--            margin-right: auto !important-->
<!--        }-->

<!--        body .is-layout-constrained>.alignwide {-->
<!--            max-width: var(--wp--style--global--wide-size)-->
<!--        }-->

<!--        body .is-layout-flex {-->
<!--            display: flex-->
<!--        }-->

<!--        body .is-layout-flex {-->
<!--            flex-wrap: wrap;-->
<!--            align-items: center-->
<!--        }-->

<!--        body .is-layout-flex>* {-->
<!--            margin: 0-->
<!--        }-->

<!--        :where(.wp-block-columns.is-layout-flex) {-->
<!--            gap: 2em-->
<!--        }-->

<!--        .has-black-color {-->
<!--            color: var(--wp--preset--color--black) !important-->
<!--        }-->

<!--        .has-cyan-bluish-gray-color {-->
<!--            color: var(--wp--preset--color--cyan-bluish-gray) !important-->
<!--        }-->

<!--        .has-white-color {-->
<!--            color: var(--wp--preset--color--white) !important-->
<!--        }-->

<!--        .has-pale-pink-color {-->
<!--            color: var(--wp--preset--color--pale-pink) !important-->
<!--        }-->

<!--        .has-vivid-red-color {-->
<!--            color: var(--wp--preset--color--vivid-red) !important-->
<!--        }-->

<!--        .has-luminous-vivid-orange-color {-->
<!--            color: var(--wp--preset--color--luminous-vivid-orange) !important-->
<!--        }-->

<!--        .has-luminous-vivid-amber-color {-->
<!--            color: var(--wp--preset--color--luminous-vivid-amber) !important-->
<!--        }-->

<!--        .has-light-green-cyan-color {-->
<!--            color: var(--wp--preset--color--light-green-cyan) !important-->
<!--        }-->

<!--        .has-vivid-green-cyan-color {-->
<!--            color: var(--wp--preset--color--vivid-green-cyan) !important-->
<!--        }-->

<!--        .has-pale-cyan-blue-color {-->
<!--            color: var(--wp--preset--color--pale-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-cyan-blue-color {-->
<!--            color: var(--wp--preset--color--vivid-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-purple-color {-->
<!--            color: var(--wp--preset--color--vivid-purple) !important-->
<!--        }-->

<!--        .has-black-background-color {-->
<!--            background-color: var(--wp--preset--color--black) !important-->
<!--        }-->

<!--        .has-cyan-bluish-gray-background-color {-->
<!--            background-color: var(--wp--preset--color--cyan-bluish-gray) !important-->
<!--        }-->

<!--        .has-white-background-color {-->
<!--            background-color: var(--wp--preset--color--white) !important-->
<!--        }-->

<!--        .has-pale-pink-background-color {-->
<!--            background-color: var(--wp--preset--color--pale-pink) !important-->
<!--        }-->

<!--        .has-vivid-red-background-color {-->
<!--            background-color: var(--wp--preset--color--vivid-red) !important-->
<!--        }-->

<!--        .has-luminous-vivid-orange-background-color {-->
<!--            background-color: var(--wp--preset--color--luminous-vivid-orange) !important-->
<!--        }-->

<!--        .has-luminous-vivid-amber-background-color {-->
<!--            background-color: var(--wp--preset--color--luminous-vivid-amber) !important-->
<!--        }-->

<!--        .has-light-green-cyan-background-color {-->
<!--            background-color: var(--wp--preset--color--light-green-cyan) !important-->
<!--        }-->

<!--        .has-vivid-green-cyan-background-color {-->
<!--            background-color: var(--wp--preset--color--vivid-green-cyan) !important-->
<!--        }-->

<!--        .has-pale-cyan-blue-background-color {-->
<!--            background-color: var(--wp--preset--color--pale-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-cyan-blue-background-color {-->
<!--            background-color: var(--wp--preset--color--vivid-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-purple-background-color {-->
<!--            background-color: var(--wp--preset--color--vivid-purple) !important-->
<!--        }-->

<!--        .has-black-border-color {-->
<!--            border-color: var(--wp--preset--color--black) !important-->
<!--        }-->

<!--        .has-cyan-bluish-gray-border-color {-->
<!--            border-color: var(--wp--preset--color--cyan-bluish-gray) !important-->
<!--        }-->

<!--        .has-white-border-color {-->
<!--            border-color: var(--wp--preset--color--white) !important-->
<!--        }-->

<!--        .has-pale-pink-border-color {-->
<!--            border-color: var(--wp--preset--color--pale-pink) !important-->
<!--        }-->

<!--        .has-vivid-red-border-color {-->
<!--            border-color: var(--wp--preset--color--vivid-red) !important-->
<!--        }-->

<!--        .has-luminous-vivid-orange-border-color {-->
<!--            border-color: var(--wp--preset--color--luminous-vivid-orange) !important-->
<!--        }-->

<!--        .has-luminous-vivid-amber-border-color {-->
<!--            border-color: var(--wp--preset--color--luminous-vivid-amber) !important-->
<!--        }-->

<!--        .has-light-green-cyan-border-color {-->
<!--            border-color: var(--wp--preset--color--light-green-cyan) !important-->
<!--        }-->

<!--        .has-vivid-green-cyan-border-color {-->
<!--            border-color: var(--wp--preset--color--vivid-green-cyan) !important-->
<!--        }-->

<!--        .has-pale-cyan-blue-border-color {-->
<!--            border-color: var(--wp--preset--color--pale-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-cyan-blue-border-color {-->
<!--            border-color: var(--wp--preset--color--vivid-cyan-blue) !important-->
<!--        }-->

<!--        .has-vivid-purple-border-color {-->
<!--            border-color: var(--wp--preset--color--vivid-purple) !important-->
<!--        }-->

<!--        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {-->
<!--            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important-->
<!--        }-->

<!--        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {-->
<!--            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important-->
<!--        }-->

<!--        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {-->
<!--            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important-->
<!--        }-->

<!--        .has-luminous-vivid-orange-to-vivid-red-gradient-background {-->
<!--            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important-->
<!--        }-->

<!--        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {-->
<!--            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important-->
<!--        }-->

<!--        .has-cool-to-warm-spectrum-gradient-background {-->
<!--            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important-->
<!--        }-->

<!--        .has-blush-light-purple-gradient-background {-->
<!--            background: var(--wp--preset--gradient--blush-light-purple) !important-->
<!--        }-->

<!--        .has-blush-bordeaux-gradient-background {-->
<!--            background: var(--wp--preset--gradient--blush-bordeaux) !important-->
<!--        }-->

<!--        .has-luminous-dusk-gradient-background {-->
<!--            background: var(--wp--preset--gradient--luminous-dusk) !important-->
<!--        }-->

<!--        .has-pale-ocean-gradient-background {-->
<!--            background: var(--wp--preset--gradient--pale-ocean) !important-->
<!--        }-->

<!--        .has-electric-grass-gradient-background {-->
<!--            background: var(--wp--preset--gradient--electric-grass) !important-->
<!--        }-->

<!--        .has-midnight-gradient-background {-->
<!--            background: var(--wp--preset--gradient--midnight) !important-->
<!--        }-->

<!--        .has-small-font-size {-->
<!--            font-size: var(--wp--preset--font-size--small) !important-->
<!--        }-->

<!--        .has-medium-font-size {-->
<!--            font-size: var(--wp--preset--font-size--medium) !important-->
<!--        }-->

<!--        .has-large-font-size {-->
<!--            font-size: var(--wp--preset--font-size--large) !important-->
<!--        }-->

<!--        .has-x-large-font-size {-->
<!--            font-size: var(--wp--preset--font-size--x-large) !important-->
<!--        }-->

<!--        .wp-block-navigation a:where(:not(.wp-element-button)) {-->
<!--            color: inherit-->
<!--        }-->

<!--        :where(.wp-block-columns.is-layout-flex) {-->
<!--            gap: 2em-->
<!--        }-->

<!--        .wp-block-pullquote {-->
<!--            font-size: 1.5em;-->
<!--            line-height: 1.6-->
<!--        }-->
<!--    </style>-->
<!--    <style type="text/css" id="wp-custom-css" media="all">-->
<!--        @media all and (min-width:1024px) {-->

<!--            .plan-names.is-stuck,-->
<!--            .pricing-row.is-stuck {-->
<!--                z-index: 200001-->
<!--            }-->
<!--        }-->

<!--        @media all and (max-width:1099px) {-->
<!--            .hero-content {-->
<!--                background-position: bottom right-->
<!--            }-->
<!--        }-->

<!--        @media all and (max-width:1023px) {-->
<!--            section.comparison-tables table tr.pricing-row a {-->
<!--                width: auto-->
<!--            }-->

<!--            section.pricing-tables.version-v2 .plan-column .plan-cta {-->
<!--                text-align: left-->
<!--            }-->

<!--            section.pricing-tables .plan-column .plan-cta a.button {-->
<!--                width: auto-->
<!--            }-->

<!--            #stickytable .pricing-row.sticky>td:first-child {-->
<!--                color: #828387;-->
<!--                font-weight: 400-->
<!--            }-->

<!--            section.comparison-tables table tbody tr.pricing-row>td:first-child {-->
<!--                font-weight: 400-->
<!--            }-->
<!--        }-->

<!--        @media all and (max-width:400px) {-->
<!--            section.pricing-tables .plan-column .plan-cta a.button {-->
<!--                width: 100%-->
<!--            }-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child {-->
<!--            padding: 30px 0;-->
<!--            margin-bottom: 40px-->
<!--        }-->

<!--        #sidemenu.menu .button {-->
<!--            position: relative;-->
<!--            padding: 0-->
<!--        }-->

<!--        #sidemenu.menu .button a,-->
<!--        #sidemenu.menu .button a:hover {-->
<!--            color: white !important;-->
<!--            padding: .7rem 1rem-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .card h5,-->
<!--        .home .entry-content>.cards-block:first-child .card .card-image {-->
<!--            display: none-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .card {-->
<!--            background: transparent;-->
<!--            border: 0;-->
<!--            margin: 0-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .card p {-->
<!--            margin: 0;-->
<!--            color: #fff-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .card .card-section {-->
<!--            padding: 0;-->
<!--            display: flex;-->
<!--            justify-content: center;-->
<!--            align-items: center-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .inner-content>.cell {-->
<!--            width: 46%-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .inner-content>.cell:first-child {-->
<!--            width: 30%;-->
<!--            padding-left: 0-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .inner-content>.cell:last-child {-->
<!--            width: 15%;-->
<!--            padding-right: 0-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child .inner-content>.cell:last-child .card-section {-->
<!--            justify-content: flex-end-->
<!--        }-->

<!--        .home .entry-content>.cards-block:first-child {-->
<!--            padding: 30px 0-->
<!--        }-->

<!--        @media all and (max-width:1023px) {-->
<!--            .home .entry-content>.cards-block:first-child .inner-content>.cell:last-child {-->
<!--                display: none-->
<!--            }-->

<!--            .home .entry-content>.cards-block:first-child .inner-content>.cell {-->
<!--                width: 50%-->
<!--            }-->

<!--            .home .entry-content>.cards-block:first-child .inner-content>.cell:first-child {-->
<!--                width: 40%-->
<!--            }-->
<!--        }-->

<!--        @media all and (max-width:767px) {-->
<!--            .home .entry-content>.cards-block:first-child .inner-content>.cell:first-child {-->
<!--                display: none-->
<!--            }-->

<!--            .home .entry-content>.cards-block:first-child .inner-content>.cell {-->
<!--                width: 100%;-->
<!--                padding: 0 30px-->
<!--            }-->
<!--        }-->

<!--        section.press-releases>.grid-container>.grid-x {-->
<!--            display: none-->
<!--        }-->

<!--        section.press-releases {-->
<!--            padding-top: 2rem-->
<!--        }-->

<!--        section.testimonial-block .header-m {-->
<!--            max-width: 80%;-->
<!--            margin: 0 auto-->
<!--        }-->

<!--        .resource-content blockquote {-->
<!--            border: 0;-->
<!--            color: #2A2E30;-->
<!--            font-family: 'ProximaNova ExtraBold', 'Helvetica Neue', Helvetica, Arial, sans-serif !important;-->
<!--            font-size: 32px;-->
<!--            font-weight: 800;-->
<!--            letter-spacing: 0;-->
<!--            line-height: 32px;-->
<!--            padding: 0;-->
<!--            margin: 30px 0-->
<!--        }-->

<!--        @media all and (min-width:1100px) {-->
<!--            .resource-content blockquote {-->
<!--                margin-left: -10%;-->
<!--                margin-right: -10%;-->
<!--                padding: 0 5%;-->
<!--                padding-right: 1%-->
<!--            }-->
<!--        }-->

<!--        .resource-content blockquote p {-->
<!--            color: #2A2E30;-->
<!--            line-height: 35px-->
<!--        }-->

<!--        @media all and (max-width:767px) {-->
<!--            section.testimonial-block .testimonials .testimonial-content p {-->
<!--                margin: 0;-->
<!--                line-height: 39px;-->
<!--                font-size: 20px;-->
<!--                line-height: 23px-->
<!--            }-->

<!--            .home .hero-content h2+p a.button-large {-->
<!--                margin-top: 5px-->
<!--            }-->
<!--        }-->

<!--        ul.gallery {-->
<!--            list-style: none !important-->
<!--        }-->

<!--        .page section.accordion-block .accordion-item .accordion-title::before {-->
<!--            color: #777-->
<!--        }-->

<!--        section.comparison-tables table tr.pricing-row span strong {-->
<!--            text-align: center;-->
<!--            width: 100%-->
<!--        }-->

<!--        @media all and (max-width:1023px) {-->
<!--            section.comparison-tables table tr.pricing-row span strong {-->
<!--                text-align: right;-->
<!--                width: 100%;-->
<!--                padding-right: 5px-->
<!--            }-->
<!--        }-->

<!--        .hide-site {-->
<!--            display: none-->
<!--        }-->

<!--        .home .hide-home {-->
<!--            display: none-->
<!--        }-->

<!--        .home .hide-site {-->
<!--            display: block-->
<!--        }-->

<!--        .page-template-landing-pages-promo .menu-icon {-->
<!--            display: none-->
<!--        }-->

<!--        .show-on-pricing {-->
<!--            display: none-->
<!--        }-->

<!--        .page-pricing .show-on-pricing,-->
<!--        .parent-pageid-60 .show-on-pricing {-->
<!--            display: block-->
<!--        }-->

<!--        .page-pricing .hide-site,-->
<!--        .parent-pageid-60 .hide-site {-->
<!--            display: none-->
<!--        }-->

<!--        .page-pricing .hide-home,-->
<!--        .parent-pageid-60 .hide-home {-->
<!--            display: none-->
<!--        }-->

<!--        .mktoMobileShow .mktoForm,-->
<!--        .mktoForm a {-->
<!--            padding: 0 !important-->
<!--        }-->

<!--        .submenu a,-->
<!--        .submenu.menu .active a {-->
<!--            font-family: "ProximaNova Medium", "Helvetica Neue", Helvetica, Arial, sans-serif-->
<!--        }-->

<!--        .submenu a .menu-item-description,-->
<!--        .submenu.menu .active a .menu-item-description {-->
<!--            font-family: "ProximaNova Regular", "Helvetica Neue", Helvetica, Arial, sans-serif-->
<!--        }-->

<!--        section.two-columns.text-content li {-->
<!--            font-size: 18px;-->
<!--            line-height: 24px;-->
<!--            margin-bottom: 10px-->
<!--        }-->

<!--        #wow-modal-window-2 {-->
<!--            box-shadow: 0 10px 10px 0 rgba(0, 0, 0, .13), 0 14px 28px 0 rgba(0, 0, 0, .12) !important;-->
<!--            bottom: 45px !important;-->
<!--            right: 43px !important-->
<!--        }-->

<!--        span.wow-modal-close-2 {-->
<!--            position: absolute;-->
<!--            right: 20px;-->
<!--            top: 20px;-->
<!--            cursor: pointer-->
<!--        }-->

<!--        #menu-item-6529 svg {-->
<!--            width: 24px;-->
<!--            height: 24px-->
<!--        }-->

<!--        @media all and (max-width:767px) {-->
<!--            #g2-crowd-widget-testimonial-14599 {-->
<!--                height: 3800px !important-->
<!--            }-->
<!--        }-->

<!--        .page-id-7868 .cards-block .card {-->
<!--            border: 0;-->
<!--            overflow: visible-->
<!--        }-->

<!--        .page-id-7868 .cards-block .card .card-section {-->
<!--            padding: 0-->
<!--        }-->

<!--        @media all and (min-width:1150px) {-->
<!--            .page-id-7868 .cards-block .cell h5 {-->
<!--                white-space: nowrap;-->
<!--                margin-top: 20px-->
<!--            }-->

<!--            .page-id-7868 .cards-block .cell {-->
<!--                padding-right: 0;-->
<!--                margin-right: 0-->
<!--            }-->
<!--        }-->

<!--        @media all and (max-width:768px) {-->
<!--            .page-id-7868 .cards-block .card .card-cta {-->
<!--                text-align: center-->
<!--            }-->

<!--            .page-id-7868 .block-intro h3 {-->
<!--                padding: 0 30px-->
<!--            }-->
<!--        }-->

<!--        @media all and (min-width:1130px) {-->
<!--            .page-id-60 h1 {-->
<!--                font-size: 50px-->
<!--            }-->
<!--        }-->
<!--    </style>-->
<!--    <style media="all">-->
<!--        .announcements {-->
<!--            display: none-->
<!--        }-->

<!--        .home .announcements {-->
<!--            display: block-->
<!--        }-->

<!--        .page-home .announcements {-->
<!--            display: block-->
<!--        }-->

<!--        .page-cp .announcements {-->
<!--            display: block-->
<!--        }-->

<!--        .announcements {-->
<!--            color: #000;-->
<!--            background-color: #CEDAFA;-->
<!--            padding: 10px 0;-->
<!--            font-family: 'ProximaNova Medium', 'Helvetica Neue', Helvetica, Arial, sans-serif-->
<!--        }-->

<!--        .announcements p {-->
<!--            margin: 0-->
<!--        }-->

<!--        .announcements a {-->
<!--            color: #000;-->
<!--            text-decoration: underline-->
<!--        }-->

<!--        .top-bar-right.show-for-small ul.menu .menu-icon::after {-->
<!--            background-image: url(https://www.svgrepo.com/show/532200/menu-alt.svg)-->
<!--        }-->

<!--        .top-bar-right.formobile ul.menu .menu-icon::after {-->
<!--            background-image: url(https://www.svgrepo.com/show/532200/menu-alt.svg)-->
<!--        }-->
<!--    </style>-->
<!--    <script>-->
<!--        window.dataLayer = window.dataLayer || [];-->

<!--        function gtag() {-->
<!--            dataLayer.push(arguments);-->
<!--        }-->
<!--        gtag('js', new Date());-->
<!--        gtag('config', 'AW-768371374');-->
<!--    </script>-->

<!--    <style media="all">-->
<!--        .bottom-cta {-->
<!--            display: none-->
<!--        }-->
<!--    </style>-->
<!--</head>-->

<!--<body class="home page-template-default page page-id-9570 wp-custom-logo page-home-2"> <a class="show-for-sr"-->
<!--        href="https://bitly.com/#content">Skip Navigation</a>-->
<!--    <div class="off-canvas-wrapper" data-sticky-container>-->
<!--        <div class="off-canvas position-right" id="off-canvas" data-off-canvas>-->
<!--            <div class="top-bar" id="top-bar-menu-off-canvas">-->
<!--                <div class="top-bar-left formobile">-->
<!--                    <div class="branding" style="padding-bottom: 10%"></div>-->
<!--                </div>-->
<!--                <div class="top-bar-right formobile">-->
<!--                    <ul class="menu">-->
<!--                        <li><button class="menu-icon" type="button" data-toggle="off-canvas">aaaaaaa</button></li>-->
<!--                    </ul>-->
<!--                </div>-->
<!--            </div>-->
<!--            <ul id="offcanvas-nav" class="vertical menu accordion-menu" data-accordion-menu data-multi-open="false">-->
<!--                <li id="menu-item-8815"-->
<!--                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8815">-->
<!--                    <a id="offcanvas-nav-products-2" href="about.php">About</a>-->
<!--                <li id="menu-item-8815"-->
<!--                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8815">-->
<!--                    <a id="offcanvas-nav-products-2" href="index.php">Home</a>-->
<!--                </li>-->
<!--                <?php if (!isset($_SESSION['username'])) { ?>-->
<!--                    <li id="menu-item-10676"-->
<!--                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10676"><a-->
<!--                            id="offcanvas-nav-10676" href="login.php">Login</a></li> <?php } else { ?>-->
<!--                    <li id="menu-item-10676"-->
<!--                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10676"><a-->
<!--                            id="offcanvas-nav-10676" href="logout.php">Logout</a></li> <?php } ?>-->
<!--                <?php if (!isset($_SESSION['username'])) { ?>-->
<!--                    <li id="menu-item-8807"-->
<!--                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-8807">-->
<!--                        <a id="offcanvas-nav-resources-4" href="signup.php">Signup</a> <?php } ?>-->
<!--                </li>-->
<!--                <?php if (isset($_SESSION['username'])) { ?>-->
<!--                    <li id="menu-item-8807"-->
<!--                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-8807">-->
<!--                        <a id="offcanvas-nav-resources-4" href="manage_url.php">Manage</a> <?php } ?>-->
<!--                        <?php if(isset($_SESSION['username'])) { ?><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a id="sidemenu-login" href="all_ads.php">Multimedia</a></li><?php }?>-->
<!--            </ul>-->
<!--            <div id="text-7" class="widget widget_text">-->
<!--                <div class="textwidget"></div>-->
<!--            </div>-->
<!--        </div>-->
<!--        <div class="off-canvas-content" data-off-canvas-content>-->
<!--            <header class="header sticky is-stuck" role="banner" data-sticky data-options="marginTop:0;"-->
<!--                data-sticky-on="small" data-check-every="0">-->
<!--                <div class="grid-container">-->
<!--                    <div class="top-bar" id="top-bar-menu">-->
<!--                        <div class="top-bar-left float-left branding"></div>-->
<!--                        <div class="top-bar-right show-for-large">-->
<!--                            <div class="nav-wrap">-->
<!--                                <ul id="main-nav" class="medium-horizontal menu"-->
<!--                                    data-responsive-menu="accordion medium-dropdown" data-closing-time="50">-->


<!--                                </ul>-->
<!--                                <ul id="sidemenu" class="medium-horizontal menu">-->
<!--                                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a-->
<!--                                            id="sidemenu-login" href="index.php">Home</a></li>-->
<!--                                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a-->
<!--                                            id="sidemenu-login" href="about.php">About</a></li>-->
<!--                                    <?php if (!isset($_SESSION['username'])) { ?>-->
<!--                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a-->
<!--                                                id="sidemenu-login" href="login.php">Log in</a></li>-->
<!--                                        <li-->
<!--                                            class="button menu-item menu-item-type-custom menu-item-object-custom menu-item-8991">-->
<!--                                            <a id="sidemenu-get-a-quote-2" href="signup.php">Sign up</a>-->
<!--                                        </li>-->
<!--                                    <?php } else { ?>-->
<!--                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a-->
<!--                                                id="sidemenu-login" href="logout.php">Log out</a></li><?php } ?>-->
<!--                                    <?php if (isset($_SESSION['username'])) { ?>-->
<!--                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a-->
<!--                                                id="sidemenu-login" href="manage_url.php">Manage</a></li><?php } ?>-->
<!--                                    <?php if(isset($_SESSION['username'])) { ?><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a id="sidemenu-login" href="all_ads.php">Multimedia</a></li><?php }?>-->

<!--                                </ul>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <div class="top-bar-right float-right show-for-small hide-for-large">-->
<!--                            <ul class="menu">-->
<!--                                <li><button class="menu-icon" type="button" data-toggle="off-canvas">Menu</button></li>-->
<!--                            </ul>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </header>-->
<!--            <hero>-->
<!--                <div class="mobile-hero-wrap slim-special"> <img-->
<!--                        src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/10/homepage-hero-a-bit-closer-desktop-v2.png">-->
<!--                </div>-->
<!--            </hero>-->
<!--            <div class="content" id="content">-->
<!--                <div class="inner-content">-->
<!--                    <main class="main" role="main">-->
<!--                        <article id="post-9570" class="post-9570 page type-page status-publish hentry" role="article"-->
<!--                            itemscope itemtype="http://schema.org/WebPage">-->
<!--                            <div class="entry-content" itemprop="text">-->
<!--                                <section class="free-hook-block V1">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="block-intro"> </div>-->
<!--                                        <div class="block-content">-->
<!--                                            <ul class="tabs" data-deep-link-off="true" data-update-history-off="true"-->
<!--                                                data-deep-link-smudge-off="true" data-deep-link-smudge-delay-off="500"-->
<!--                                                data-tabs id="freehook-tabs">-->
<!--                                                <li class="tabs-title is-active"> <a id="tab-short-link"-->
<!--                                                        href="https://bitly.com/#panel-short-link" aria-selected="true">-->
<!--                                                        <img src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/links.svg"-->
<!--                                                            alt="Search"> <span>Search</span> </a> </li>-->
<!--                                            </ul>-->
<!--                                            <div class="tabs-content" data-tabs-content="freehook-tabs">-->
<!--                                                <div class="tabs-panel is-active" id="panel-short-link">-->
<!--                                                    <div class="tabintro">-->
<!--                                                        <p class="header-m">Search your link</p>-->
<!--                                                    </div>-->
<!--                                                    <div class="tabform">-->
<!--                                                        <form id="form-short-link" class="freehook-form" method="GET"-->
<!--                                                            action="/a/sign_up" novalidate>-->
<!--                                                            <div-->
<!--                                                                class="inner-content grid-x grid-margin-x grid-padding-x-off form-content">-->
<!--                                                                <div class="cell large-12">-->
<!--                                                                    <div class="infobox"><img-->
<!--                                                                            class="alignnone size-full wp-image-10086"-->
<!--                                                                            role="img"-->
<!--                                                                            src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/stars.svg"-->
<!--                                                                            alt="" width="20" height="20"> End your link-->
<!--                                                                        with words that will make it unique</div>-->
<!--                                                                </div><?php $url = 'search.php'; ?>-->
<!--                                                                <div class="cell large-12"> <label><br> <input-->
<!--                                                                            type="url" class="hook_url"-->
<!--                                                                            placeholder="Example: breaking bad, sasuke, nissan r34"-->
<!--                                                                            id="param1" tabindex="50"-->
<!--                                                                            style="text-align:center"> </label> </div>-->
<!--                                                                <div class="cell large-7"> </div>-->
<!--                                                                <div-->
<!--                                                                    class="cell large-12 errormessage for-hook_backhalf">-->
<!--                                                                </div>-->
<!--                                                                <div class="cell large-12"-->
<!--                                                                    style="display: flex;justify-content:center;">-->
<!--                                                                    <input tabindex="52" type="button"-->
<!--                                                                        class="button button-primary button-large"-->
<!--                                                                        value="Go"-->
<!--                                                                        onclick="window.location.href = '<?php echo $url; ?>?q=' + document.getElementById('param1').value">-->
<!--                                                                </div>-->
<!--                                                            </div> <input type="hidden" class="hook_type"-->
<!--                                                                value="bitlinks"> <input type="hidden" name="rd"-->
<!--                                                                value="/default/bitlinks">-->
<!--                                                        </form>-->
<!--                                                    </div>-->
<!--                                                </div>-->
<!--                                                <div class="tabs-panel" id="panel-qr-code">-->
<!--                                                    <div class="tabintro">-->
<!--                                                        <p class="header-m">Create a QR Code</p>-->
<!--                                                    </div>-->
<!--                                                    <div class="tabform">-->
<!--                                                        <form id="form-qr-code" class="freehook-form" method="GET"-->
<!--                                                            action="/a/sign_up" novalidate>-->
<!--                                                            <div-->
<!--                                                                class="inner-content grid-x grid-margin-x grid-padding-x-off form-content align-top">-->
<!--                                                                <div class="cell large-6"> <label>Enter your QR Code-->
<!--                                                                        destination<br> <input tabindex="53" type="url"-->
<!--                                                                            id="form-qr-long-url" class="hook_url"-->
<!--                                                                            placeholder="Example: http://super-long-link.com">-->
<!--                                                                    </label>-->
<!--                                                                    <div class="errormessage for-hook_url"></div>-->
<!--                                                                </div>-->
<!--                                                                <div class="cell large-6">-->
<!--                                                                    <div class="infobox infobox-2col col-6-6">-->
<!--                                                                        <div><img-->
<!--                                                                                class="alignnone size-full wp-image-10089"-->
<!--                                                                                src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/free-hook_qrc.png"-->
<!--                                                                                alt="" width="224" height="123"-->
<!--                                                                                style="width:224px;height:123px"> </div>-->
<!--                                                                        <div>-->
<!--                                                                            <p><strong>QR Codes are everywhere</strong>-->
<!--                                                                            </p>-->
<!--                                                                            <p>Connect your real-world audience to your-->
<!--                                                                                online content.</p>-->
<!--                                                                        </div>-->
<!--                                                                    </div>-->
<!--                                                                </div>-->
<!--                                                                <div class="cell large-12"> <input tabindex="54"-->
<!--                                                                        type="button"-->
<!--                                                                        class="button button-primary button-large"-->
<!--                                                                        value="Sign up and get your QR Code"-->
<!--                                                                        id="form-qr-submit"> </div>-->
<!--                                                            </div> <input type="hidden" class="hook_type"-->
<!--                                                                value="qrcodes"> <input type="hidden" name="rd"-->
<!--                                                                value="/default/qrcodes">-->
<!--                                                        </form>-->
<!--                                                    </div>-->
<!--                                                </div>-->
<!--                                                <div class="tabs-panel" id="panel-lib">-->
<!--                                                    <div class="tabintro">-->
<!--                                                        <p class="header-m">Build a Link-in-bio page and showcase your-->
<!--                                                            links</p>-->
<!--                                                    </div>-->
<!--                                                    <div class="tabform">-->
<!--                                                        <form id="form-lib" class="freehook-form" method="GET"-->
<!--                                                            action="/a/sign_up" novalidate>-->
<!--                                                            <div-->
<!--                                                                class="inner-content grid-x grid-margin-x grid-padding-x-off form-content">-->
<!--                                                                <div class="cell large-5 remove-margin-small"> <label-->
<!--                                                                        for="lib-domain-disabled">Claim your Link-in-bio-->
<!--                                                                        URL<span class="help">?</span><span-->
<!--                                                                            class="help-text-info"><span-->
<!--                                                                                class="info-inner">The link you'll share-->
<!--                                                                                to take people to your Link-in-bio-->
<!--                                                                                page</span></span><br> <input-->
<!--                                                                            type="text" id="lib-domain-disabled"-->
<!--                                                                            disabled placeholder="bit.ly/m/">-->
<!--                                                                        <div class="lock-hover"><span-->
<!--                                                                                class="help help-lock"-->
<!--                                                                                id="form-lib-custom-domain-help">?</span><span-->
<!--                                                                                class="help-text-info"><span-->
<!--                                                                                    class="info-inner">Unavailable on-->
<!--                                                                                    free accounts. <a-->
<!--                                                                                        href="https://bitly.com/pages/pricing"-->
<!--                                                                                        id="form-lib-upgrade-link">Upgrade</a>-->
<!--                                                                                    to use a custom domain</span></span>-->
<!--                                                                        </div>-->
<!--                                                                    </label> </div>-->
<!--                                                                <div class="cell large-7"> <label><br-->
<!--                                                                            class="show-for-large"> <input-->
<!--                                                                            id="form-lib-backhalf" tabindex="55"-->
<!--                                                                            type="text" class="hook_backhalf"-->
<!--                                                                            placeholder="example: very-important-links">-->
<!--                                                                    </label> </div>-->
<!--                                                                <div-->
<!--                                                                    class="cell large-12 errormessage for-hook_backhalf">-->
<!--                                                                </div>-->
<!--                                                                <div class="cell large-12">-->
<!--                                                                    <div class="infobox infobox-2col col-3-9">-->
<!--                                                                        <div><img-->
<!--                                                                                class="alignnone size-full wp-image-10088"-->
<!--                                                                                src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/02_lib-onboarding@2x.png"-->
<!--                                                                                alt="" width="200" height="165"-->
<!--                                                                                style="width:200px;height:auto"> </div>-->
<!--                                                                        <div>-->
<!--                                                                            <p><strong>Create a page for all your-->
<!--                                                                                    links</strong></p>-->
<!--                                                                            <p>Make it easy for your customers and-->
<!--                                                                                followers to engage with your select-->
<!--                                                                                links. Design a stunning, compact page,-->
<!--                                                                                share it, and watch the clicks roll in.-->
<!--                                                                            </p>-->
<!--                                                                        </div>-->
<!--                                                                    </div>-->
<!--                                                                </div>-->
<!--                                                                <div class="cell large-12"> <input type="button"-->
<!--                                                                        tabindex="56" id="form-lib-submit"-->
<!--                                                                        class="button button-primary button-large"-->
<!--                                                                        value="Sign up and create your page"> </div>-->
<!--                                                            </div> <input type="hidden" class="hook_type"-->
<!--                                                                value="launchpads"> <input type="hidden" name="rd"-->
<!--                                                                value="/default/bitlinks">-->
<!--                                                        </form>-->
<!--                                                    </div>-->
<!--                                                </div>-->
<!--                                                <div class="block-footer">-->
<!--                                                    <p class="subhead-xl" style="text-align: center; color: #252628;">-->
<!--                                                    </p>-->
<!--                                                    <ul>-->
<!--                                                        <li><img decoding="async" loading="lazy"-->
<!--                                                                class="alignnone size-full wp-image-10090" role="img"-->
<!--                                                                src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/checked.svg"-->
<!--                                                                alt="" width="24" height="24">Numeric links</li>-->
<!--                                                        <li><img decoding="async" loading="lazy"-->
<!--                                                                class="alignnone size-full wp-image-10090" role="img"-->
<!--                                                                src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/checked.svg"-->
<!--                                                                alt="" width="24" height="24">QR Codes</li>-->
<!--                                                        <li><img decoding="async" loading="lazy"-->
<!--                                                                class="alignnone size-full wp-image-10090" role="img"-->
<!--                                                                src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2023/02/checked.svg"-->
<!--                                                                alt="" width="24" height="24">NFC</li>-->
<!--                                                    </ul>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="three-columns text-content fancy-list rounded-cards">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="inner-content grid-x grid-margin-x grid-padding-x align-top">-->
<!--                                            <div class="cell">-->
<!--                                                <div class="block-intro">-->
<!--                                                    <h3 class="header-m"-->
<!--                                                        style="text-align: center; max-width: 800px; margin-left: auto; margin-right: auto; margin-top: 50px;">-->
<!--                                                        The Bitly Connections Platform</h3>-->
<!--                                                    <h4-->
<!--                                                        style="text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;">-->
<!--                                                        All the products you need to build brand connections, manage-->
<!--                                                        links and QR Codes, and connect with audiences everywhere, in a-->
<!--                                                        single unified platform.</h4>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                        <div class="inner-content grid-x grid-margin-x grid-padding-x align-top">-->
<!--                                            <div class="cell large-4">-->
<!--                                                <div class="content-padding">-->
<!--                                                    <h5><img decoding="async" loading="lazy"-->
<!--                                                            class="alignnone size-full wp-image-8590" role="img"-->
<!--                                                            src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/06/link-mngt-3.svg"-->
<!--                                                            alt="" width="40" height="40">Link Management</h5>-->
<!--                                                    <p>A comprehensive solution to help make every point of connection-->
<!--                                                        between your content and your audience more powerful.</p>-->
<!--                                                    <hr>-->
<!--                                                    <p><strong>Popular Link Management Features</strong></p>-->
<!--                                                    <ul>-->
<!--                                                        <li>URL shortening at scale</li>-->
<!--                                                        <li>Custom links with your brand</li>-->
<!--                                                        <li>URL redirects</li>-->
<!--                                                        <li>Advanced analytics & tracking</li>-->
<!--                                                    </ul>-->
<!--                                                    <p><a id="pricing_clicked_link_management"-->
<!--                                                            class="button button-wide"-->
<!--                                                            href="https://bitly.com/pages/pricing">Get Started for-->
<!--                                                            Free</a><br> </p>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                            <div class="cell large-4">-->
<!--                                                <div class="content-padding">-->
<!--                                                    <h5><img decoding="async" loading="lazy"-->
<!--                                                            class="alignnone size-full wp-image-8591" role="img"-->
<!--                                                            src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/06/qr-code.svg"-->
<!--                                                            alt="" width="40" height="40">QR Codes</h5>-->
<!--                                                    <p>QR Code solutions for every customer, business and brand-->
<!--                                                        experience.</p>-->
<!--                                                    <hr>-->
<!--                                                    <p><strong>Popular QR Code Features</strong></p>-->
<!--                                                    <ul>-->
<!--                                                        <li>Fully customizable QR Codes</li>-->
<!--                                                        <li>Dynamic QR Codes</li>-->
<!--                                                        <li>QR Code types & destination options</li>-->
<!--                                                        <li>Advanced analytics & tracking</li>-->
<!--                                                    </ul>-->
<!--                                                    <p><a id="pricing_clicked_qr_codes" class="button button-wide"-->
<!--                                                            href="https://bitly.com/pages/pricing">Get Started for-->
<!--                                                            Free</a><br> </p>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                            <div class="cell large-4">-->
<!--                                                <div class="content-padding">-->
<!--                                                    <h5><img decoding="async" loading="lazy"-->
<!--                                                            class="alignnone size-full wp-image-8592" role="img"-->
<!--                                                            src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/06/link-in-bio-1.svg"-->
<!--                                                            alt="" width="40" height="40">Link-in-bio <span-->
<!--                                                            class="new">NEW</span></h5>-->
<!--                                                    <p>Bitly Link-in-bio, powered by Bitly Link Management, to help you-->
<!--                                                        curate, package and track your best links.</p>-->
<!--                                                    <hr>-->
<!--                                                    <p><strong>Popular Link-in-bio Features</strong></p>-->
<!--                                                    <ul>-->
<!--                                                        <li>Custom URLs for social media</li>-->
<!--                                                        <li>Customizable landing page</li>-->
<!--                                                        <li>Easy-to-manage links</li>-->
<!--                                                        <li>Link and landing page tracking</li>-->
<!--                                                    </ul>-->
<!--                                                    <p><a id="pricing_clicked_link_in_bio" class="button button-wide"-->
<!--                                                            href="https://bitly.com/pages/pricing">Get Started for-->
<!--                                                            Free</a><br> </p>-->
<!--                                                </div>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="content-divider">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="cell">-->
<!--                                            <hr>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="content-divider">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="cell">-->
<!--                                            <hr>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="content-divider">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="cell">-->
<!--                                            <hr>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="content-divider">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="cell">-->
<!--                                            <hr>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                                <section class="full-width-content text-content dark-row"-->
<!--                                    style="background-image:url();background-color:#0b1736">-->
<!--                                    <div class="grid-container">-->
<!--                                        <div class="inner-content grid-x grid-margin-x grid-padding-x">-->
<!--                                            <div class="cell">-->
<!--                                                <h3 style="text-align: center;">More than a QR code</h3>-->
<!--                                                <p style="text-align: center; margin-top: 40px;"><a-->
<!--                                                        id="free-plan-btn-footer-widget-home"-->
<!--                                                        class="button button-large" href="signup.php">Get Started</a>-->
<!--                                                </p>-->
<!--                                            </div>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </section>-->
<!--                            </div>-->
<!--                        </article>-->
<!--                    </main>-->
<!--                </div>-->
<!--            </div>-->
<!--            <section class="bottom-cta">-->
<!--                <div id="custom_html-2" class="widget_text page-bottom widget widget_custom_html">-->
<!--                    <div class="textwidget custom-html-widget">-->
<!--                        <section class="full-width-content text-content dark-row" style="background-color:#0b1736">-->
<!--                            <div class="grid-container">-->
<!--                                <div class="inner-content grid-x grid-margin-x grid-padding-x">-->
<!--                                    <div class="cell">-->
<!--                                        <div class="hide-home">-->
<!--                                            <h3 style="text-align: center;">Get closer to your audience and customers-->
<!--                                                today</h3>-->
<!--                                            <p> </p>-->
<!--                                            <p style="text-align: center;"><a class="button button-lg"-->
<!--                                                    id="free-plan-btn-footer-widget-site"-->
<!--                                                    href="https://bitly.com/pages/pricing">Start for Free</a></p>-->
<!--                                        </div>-->
<!--                                        <div class="hide-site">-->
<!--                                            <h3 style="text-align: center;">More than a free link shortener</h3>-->
<!--                                            <p> </p>-->
<!--                                            <p style="text-align: center;"><a class="button button-lg"-->
<!--                                                    id="free-plan-btn-footer-widget-home"-->
<!--                                                    href="https://bitly.com/pages/pricing">Get Started</a></p>-->
<!--                                        </div>-->
<!--                                        <div class="show-on-pricing">-->
<!--                                            <h3 style="text-align: center;">Get closer to your audience and customers-->
<!--                                                today</h3>-->
<!--                                            <p> </p>-->
<!--                                            <p style="text-align: center;"><a class="button button-lg"-->
<!--                                                    id="free-plan-btn-footer-widget-pricing"-->
<!--                                                    href="https://bitly.com/a/sign_up">Start for Free</a></p>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </section>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </section>-->
<!--            <footer class="footer" role="contentinfo">-->
<!--                <div class="grid-container"> </div>-->
<!--            </footer>-->
<!--        </div>-->
<!--    </div>-->



<!--    <div class="icon-bag"></div>-->


<!--    <script id="hs-script-loader" async defer src="asset/26740822.js"></script>-->
<!--    <div class="hide">-->
<!--        <li class="promo-customize" style="display:none">-->
<!--            <h5>Need more redirects, custom back-half links, or QR Codes?</h5> <a class="button button-primary"-->
<!--                href="https://bitly.com/pages/pricing">Check out Starter Plan</a>-->
<!--        </li>-->
<!--    </div>-->
<!--    <div class="reveal" id="qr-modal" aria-labelledby="modal-header" data-reveal>-->
<!--        <div class="inner">-->
<!--            <p class="lead" style="text-align:center"><img-->
<!--                    src="https://docrdsfx76ssb.cloudfront.net/static/1687458771/pages/wp-content/uploads/2022/06/qr-generator.png"-->
<!--                    class="qr-img"></p>-->
<!--            <h4 id="modal-header">Taking you to QR Code Generator, part of the Bitly family</h4>-->
<!--            <div class="secondary progress" role="progressbar" aria-valuenow="0" aria-valuemin="0"-->
<!--                aria-valuetext="0 percent" aria-valuemax="100">-->
<!--                <div class="progress-meter"></div>-->
<!--            </div>-->
<!--            <p class="lead-off" style="text-align:center"><a-->
<!--                    href="https://login.qr-code-generator.com/signup/?utm_source=bitly&utm_medium=referral&utm_campaign=brand-campaign-2022&utm_content=home"-->
<!--                    style="color:#1d1f21;text-decoration:underline" class="qr-link">Click here if you don’t redirect in-->
<!--                    5 seconds</a></p>-->

<!--        </div>-->
<!--    </div>-->
<!--    <style media="all">-->
<!--        .hero-content.slim-special {-->
<!--            min-height: 435px-->
<!--        }-->

<!--        @media all and (max-width:1023px) {-->
<!--            .slim-special img {-->
<!--                opacity: 0;-->
<!--                height: 100px-->
<!--            }-->
<!--        }-->

<!--        .mobile-hero-wrap>img {-->
<!--            margin: 0 auto-->
<!--        }-->

<!--        .scroll-for-more {-->
<!--            display: none-->
<!--        }-->

<!--        h1.header-xl,-->
<!--        h1,-->
<!--        .header-xl {-->
<!--            font-size: 28px;-->
<!--            line-height: 32px-->
<!--        }-->

<!--        @media all and (min-width:992px) {-->

<!--            h1.header-xl,-->
<!--            h1,-->
<!--            .header-xl {-->
<!--                font-size: 40px;-->
<!--                line-height: 48px-->
<!--            }-->
<!--        }-->

<!--        .announcements {-->
<!--            display: block-->
<!--        }-->

<!--        @media all and (max-height:770px) and (min-width:1024px) {-->
<!--            .page-v2 .hero-content {-->
<!--                min-height: 500px-->
<!--            }-->
<!--        }-->
<!--    </style>-->
<!--</body>-->

<!--</html>-->
<?php
session_start();

include 'connection.php';
if (isset($_SESSION['username'])) {
    header('Location: manage_url.php');
    exit;
}

$error_message = '';
if (isset($_POST['login'])) {
  $connection = mysqli_connect($db_host, $db_username, $db_password, $db_name);

  // Sanitize user input to prevent SQL injection
  $username = mysqli_real_escape_string($connection, $_POST['username']);
  $password = mysqli_real_escape_string($connection, $_POST['password']);

  // Check if the username and password match
  $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  $result = mysqli_query($connection, $query);
  $users = mysqli_fetch_assoc($result);
  if (mysqli_num_rows($result) > 0) {
    $_SESSION['username'] = $users['id'];
    header('Location: manage_url.php');
    exit;
    
  } else {
    $error_message = 'Invalid username or password. Please try again.';
  }
}
?>
<!DOCTYPE HTML>
<html lang="en-US">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta content="IE=edge" http-equiv="X-UA-Compatible" />
  <meta name="referrer" content="origin" />

  <title>Artwear</title>


  <script type="text/javascript" src="asset/bitly2/7E5082ED6DA0B03895F46BF975F63B8C8B1315CF.js"></script>


  <meta name="viewport" content="width=device-width,minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">


  <link rel="stylesheet" href="asset/bitly2/17BADEBB7C21D5F4FD125352FB4499EFABC75663.css">












</head>

<body class="registration-pages sign_in">





  <noscript>
    <img
      src="https://ad.doubleclick.net/ddm/activity/src=12389169;type=conve0;cat=signu0;u1=[Plan Tier];dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;tfua=;npa=;gdpr=${GDPR};gdpr_consent=${GDPR_CONSENT_755};ord=1?"
      width="1" height="1" alt="" />
  </noscript>


  <div class="container-header">
    <h2 class=""><a href="https://scannabl.ink" style="text-decoration:none; color:black" rel="nofollow">Artwear</a>
    </h2>
    <div class="signup-flow-container hidden">
      <span class="signup-flow-elem em">Create an <br class="signup-flow-br">account</span>
      <hr>
      <span class="signup-flow-elem"> Enter payment <br class="signup-flow-br">information</span>
      <hr>
      <span class="signup-flow-elem">Get your free <br class="signup-flow-br">domain</span>
    </div>
  </div>
  <div class="signup-flow-container hidden post-header">
    <span class="signup-flow-elem em">Create an <br class="signup-flow-br">account</span>
    <hr>
    <span class="signup-flow-elem"> Enter payment <br class="signup-flow-br">information</span>
    <hr>
    <span class="signup-flow-elem">Get your free <br class="signup-flow-br">domain</span>
  </div>
  <div class="container-box title">
    <h3 class="switch to-sign-in tagline">Sign up and <br class="br">start shortening</h3>
    <h3 class="switch to-sign-up tagline">Log in and <br class="br">start sharing</h3>
    <div class="t-center">
      <div class="switch to-sign-up" tabindex="7">
        <span class="gray-link">Don't have an account?</span>
        <a id="sign-up-link" href="signup.php">Sign up</a>
      </div>
      <span class="switch to-sign-in" tabindex="8">
        <span class="gray-link">Already have an account?</span>
        <br class="br">
        <a id="sign-in-link" href="https://bitly.com//a/sign_in">Log in</a>
        <span>&bull;</span>
        <span class="switch"><a id="sso-sign-in-link-top" href="https://bitly.com//sso/url_slug" tabindex="9">Log in
            with SSO</a></span>
      </span>
    </div>
  </div>
  <div class="container-box">
    <form id="sign-up" method="POST">
      <div class="social-sign-in">
        <a id="google-sign-up" rel="nofollow" href="https://bitly.com//a/add_google_account?rd=%2f"
          class="susi-btn social-susi-btn button" data-network="google"><img
            src="https://d1ayxb9ooonjts.cloudfront.net/bitly2/7D3D4B49B3CB108E9DD416FA967849FBABBC49CF.svg" alt="Google"
            width="20"><span class="sign-up-text">Sign up with Google</span></a>
      </div>
      <p class="separator t-center">
        <span>Or</span>
      </p>
      <div class="susi-fields-wrapper">
        <fieldset>
          <label class="text" for="username">Username</label>
          <input class="text" type="text" name="username" autocomplete="username" tabindex="3" autocorrect="off"
            autocapitalize="none" />
          <span class="error-message hidden"></span>
          <label class="text" for="email">Email address</label>

          <input class="text" type="text" name="email" autocomplete="email" tabindex="4" autocorrect="off"
            autocapitalize="none" />

          <span class="error-message hidden"></span>
          <label class="text" for="password">
            Password

          </label>
          <input class="pw text" type="password" name="password" autocomplete="new-password" tabindex="5"
            autocorrect="off" autocapitalize="none" />
          <span class="error-message hidden"></span>
          <div class="switch to-sign-in password-tip">
            <div class="strength">
              <div class="strength--item">
                <div class="strength--indicator">&bull;</div>
                <div class="strength--text">6 or more characters</div>
              </div>
              <div class="strength--item">
                <div class="strength--indicator">&bull;</div>
                <div class="strength--text">One number</div>
              </div>
              <div class="strength--item">
                <div class="strength--indicator">&bull;</div>
                <div class="strength--text">One letter</div>
              </div>
              <div class="strength--item">
                <div class="strength--indicator">&bull;</div>
                <div class="strength--text">One special character</div>
              </div>
            </div>
          </div>
          <input type="hidden" name="rd" value="/" />
          <input type="hidden" name="invite_token" value="" />

          <input id="submit" type="submit" class="button button-primary sign-up-in" value="Sign up with Email"
            tabindex="8" onclick="onSubmit()" />
        </fieldset>
      </div>
    </form>
    <form method="POST">
      <input type="hidden" name="_xsrf" value="41a205b8-2d89-e18e-7994-0bc65757f3b8">
      <input type="hidden" name="rd" value="/" />


      <div class="susi-fields-wrapper">
        <fieldset>
          <label class="text" for="username">Email address or username</label>

          <input class="text" type="text" name="username" tabindex="3" autocorrect="off" autocapitalize="none" />

          <label class="text" for="password">
            Password

          </label>
          <input class="pw text" type="password" name="password" tabindex="4" autocomplete="current-password"
            autocorrect="off" autocapitalize="none" />
          <span class="error-message hidden"></span>
          <span class="error-message">

          </span>
          <input type="hidden" name="rd" value="/" />
          <input type="submit" class="button button-primary sign-up-in" value="Log in" tabindex="5" name="login" />
        </fieldset>
      </div>
    </form>


  </div>




  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="asset/bitly2/FAA16645610A1B983A0D2D86A506687C1273062F.js"></script>
  <script type="text/javascript" src="asset/bitly2/F2646B87E57084653A49DC39069E1F63751169F4.js"></script>
  <script type="text/javascript" src="asset/bitly2/DC48A284F7A5AC5604D42ED052CAD24392789DCB.js"></script>
  <script type="text/javascript" src="asset/bitly2/132D7290946D6B91858A8479F5D7E2E479A2F090.js"></script>
  <script type="text/javascript" src="asset/bitly2/D0BB1779B2B982C44A0324259497832B80101BDE.js"></script>
  <script type="text/javascript" src="asset/bitly2/2071816E49F66173069ABF96EC1CCDB1CA98AD0D.js"></script>





  <script type="text/javascript">
    (function (i, s, o, g, r, a, m) {
      i["GoogleAnalyticsObject"] = r; i[r] = i[r] || function () {
        (i[r].q = i[r].q || []).push(arguments)
      }, i[r].l = 1 * new Date(); a = s.createElement(o),
        m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
    })(window, document, "script", "//www.google-analytics.com/analytics.js", "ga");

    (function (w, d) {

      var gaId = "UA-25224921-3";



      w.ga("create", gaId, "auto");



      var accountType = "user";


      w.ga("set", "dimension2", accountType);


      w.ga("send", "pageview");
    })(window, document);
  </script>



  <script async src="https://www.googletagmanager.com/gtag/js?id=G-567GCTL9BB"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { window.dataLayer.push(arguments); }
    gtag("js", new Date());
    gtag("config", "G-567GCTL9BB", {
      send_page_view: true
    });
    gtag("config", "AW-768371374");
    gtag("config", "DC-12998045");

    gtag("config", "DC-12389169");
  </script>


  <script>
    !function (f, b, e, v, n, t, s) {
      if (f.fbq) return; n = f.fbq = function () {
        n.callMethod ?
        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
      };
      if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0";
      n.queue = []; t = b.createElement(e); t.async = !0;
      t.src = v; s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s)
    }(window, document, "script",
      "https://connect.facebook.net/en_US/fbevents.js");
    fbq("init", "575684804151769");
    fbq("track", "PageView");
  </script>
  <noscript>
    <img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=575684804151769&ev=PageView&noscript=1" />
  </noscript>
  <script type="text/javascript">
    _linkedin_partner_id = "3409844";
    window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
    window._linkedin_data_partner_ids.push(_linkedin_partner_id);
  </script>
  <script type="text/javascript">
    (function (l) {
      if (!l) {
        window.lintrk = function (a, b) { window.lintrk.q.push([a, b]) };
        window.lintrk.q = []
      }
      var s = document.getElementsByTagName("script")[0];
      var b = document.createElement("script");
      b.type = "text/javascript"; b.async = true;
      b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
      s.parentNode.insertBefore(b, s);
    })(window.lintrk);
  </script>
  <noscript>
    <img height="1" width="1" style="display:none;" alt=""
      src="https://px.ads.linkedin.com/collect/?pid=3409844&fmt=gif" />
  </noscript>

  <script>
    !function (e, t, n, s, u, a) {
      e.twq || (s = e.twq = function () {
        s.exe ? s.exe.apply(s, arguments) : s.queue.push(arguments);
      }, s.version = '1.1', s.queue = [], u = t.createElement(n), u.async = !0, u.src = '//static.ads-twitter.com/uwt.js',
        a = t.getElementsByTagName(n)[0], a.parentNode.insertBefore(u, a))
    }(window, document, 'script');

    twq("init", "o2pdk");
    twq("track", "PageView");
  </script>

  <script>

    (function (w, d) {
      var id = 'pdst-capture', n = 'script';
      if (!d.getElementById(id)) {
        w.pdst =
          w.pdst ||
          function () {
            (w.pdst.q = w.pdst.q || []).push(arguments);
          };
        var e = d.createElement(n); e.id = id; e.async = 1;
        e.src = 'https://cdn.pdst.fm/ping.min.js';
        var s = d.getElementsByTagName(n)[0];
        s.parentNode.insertBefore(e, s);
      }
      w.pdst('conf', { key: "96312ad4d097468aab67dc86ba4c34fd" });
      w.pdst('view');
    })(window, document);
  </script>


  <script>

    (function (w, d, t, r, u) {
      var f, n, i;
      w[u] = w[u] || [], f = function () {
        var o = { ti: "", enableAutoSpaTracking: true };
        o.q = w[u], w[u] = new UET(o), w[u].push("pageLoad")
      },
        n = d.createElement(t), n.src = r, n.async = 1, n.onload = n.onreadystatechange = function () {
          var s = this.readyState;
          s && s !== "loaded" && s !== "complete" || (f(), n.onload = n.onreadystatechange = null)
        },
        i = d.getElementsByTagName(t)[0], i.parentNode.insertBefore(n, i)
    })
      (window, document, "script", "//bat.bing.com/bat.js", "uetq");

  </script>

</body>

</html>










<script>

  var inputs = $('#sign-in').find('input');
  var errorMessage = $('.error-message');


  function clearErrors() {
    errorMessage.addClass('hidden');
  }


  inputs.on('input', clearErrors);
</script>